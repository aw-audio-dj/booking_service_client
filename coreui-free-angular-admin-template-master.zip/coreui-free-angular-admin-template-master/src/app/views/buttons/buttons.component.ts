import { Component } from '@angular/core';

@Component({
  templateUrl: 'buttons.component.html'
})
export class ButtonsComponent {

  constructor() { }

}
